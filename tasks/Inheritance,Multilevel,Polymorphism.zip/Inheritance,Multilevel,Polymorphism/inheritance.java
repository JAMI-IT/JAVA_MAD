package classes;

public class inheritance {
    public static void main(String[] args) {
       
        // cat c = new cat();
        // c.makesound();

        // Dog d  = new Dog();
        // d.makesound();

        // Animal a = new Dog();
        // a.makesound();

        // a = new cat();
        // a.makesound();

        // a.AnimalType();

        /*
         * Electronics device = new tv();
         * 
         * if(!device.isOn()){
         *  device.on()    // tv is on
         * }
         * device.next()  // Current channel is 2
         * device.prev()  // current channel is 99
         * 
         * device.off()  // tv is off
         * 
         * Electronics device = new Ac();
        * 
         * if(!device.isOn()){
         *  device.on()    // ac is on
         * }
         * device.next()  // Current temp is 18
         * device.prev()  // current temp is 17
         * 
         * device.off()  // Ac is off
         * 
         */
        
    }
    
}
