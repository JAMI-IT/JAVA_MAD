package classes;

public class mammals extends  Animal {
    
    @Override
    public void AnimalType() {
      System.out.print(" is a mamal");
    }
}
