package classes;

public class Dog extends mammals {
    @Override
    public void makesound() {
        System.out.println("Dog can bark");
    }
    @Override
    public void AnimalType() {
        System.out.print("Dog");
        super.AnimalType();
    }
}
