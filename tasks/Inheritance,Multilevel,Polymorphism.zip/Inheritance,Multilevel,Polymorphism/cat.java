package classes;

public class cat extends mammals {
    
    @Override
    public void makesound() {
        System.out.println("Cat says meow");
    }

    @Override
    public void AnimalType() {
        System.out.print("Cat");
        super.AnimalType();
    }
    
  
}
